var assert = require('assert');
const Servicos = require('../src/api/servicos');

describe('calculaRotas', function () {    
      it('Deveria retornar as rotas conforme saída definida', function () {

        let rotas;
        Servicos.verificaDados(()=>{
          Servicos.calculaRotas((ret)=>{
            rotas = String(ret);
            assert.equal(rotas, "SF WS 1,LS LV BC 2,WS SF LV BC 5");
          });
        });

      });    
  });


  describe('carregaTrechos', function () {    
    it('Deveria retornar os trechos do arquivo', function () {
  
      Servicos.carregaTrechos("", (ret) => {
        assert.equal(String(ret).length, 106);
      });
    });    
  });
  
  describe('carregaEncomendas', function () {    
    it('Deveria retornar as encomendas do arquivo', function () {
  
      Servicos.carregaEncomendas("", (ret) => {
        assert.equal(String(ret).length, 19);
      });
    });    
  });
  